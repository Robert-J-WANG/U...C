# Bug-Tracking-System-with-Access-Database
The aim is to design, develop with database Queries and test a bug tracking system.  

## Contents: 
###### Database Design: Conceptual ERD, Logical ERD  Database tables System
###### Implementation: Design and development of the management and tracking system using a database management system and application development environment with Microsoft Access.
###### Database tables definitions (includes attributes, primary and foreign keys).

## System Contain following information 
###### Bug/issue (name, status, severity, priority) 
###### Tester
###### Project
###### Test case
###### Graphical display number of open issue per each project during selected period of time (one week, two weeks, one month).
###### Graphical display number of closed issue per each project during selected period of time (one week, two weeks, one month).





# LOGIN Credential


##### User: Stan
##### Password: john


