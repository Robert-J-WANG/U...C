package cs.tariq.assignmentunittestdemo;

public class MyLib {

    public static int max(int a, int b){
        if(a>b)
            return a;
        else
            return b;
    }
    public static int sum(int a, int b){

            return a+b;


    }
}
