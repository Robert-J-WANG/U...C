package cs.tariq.assignmentunittestdemo;

import junit.framework.TestCase;

import org.junit.Test;

public class MyLibTest extends TestCase {

    public void testMax() {
        int n1 =10;
        int n2= 20;
        assertEquals(n2, MyLib.max(n1,n2));
    }

    @Test
    public void test2Max() {
        int n1 =-10;
        int n2= -20;
        assertEquals(n1, MyLib.max(n1,n2));

    }

    public void testSum() {
        int n1 =10;
        int n2= 20;
        assertEquals(n1+n2, MyLib.sum(n1,n2));
    }
}