package cs.tariq.assignmentunittestdemo;

import junit.framework.TestCase;

public class BookingTest extends TestCase {

    public void testBookTimeSlot() {
        Booking booking = new Booking();
        Customer customer = new Customer("John");

        assertFalse(booking.bookTimeSlot(customer,"Mon", 7));
    }
    public void test2BookTimeSlot() {
        Booking booking = new Booking();
        Customer customer = new Customer("John");

        assertTrue(booking.bookTimeSlot(customer,"Mon", 10));
    }
}