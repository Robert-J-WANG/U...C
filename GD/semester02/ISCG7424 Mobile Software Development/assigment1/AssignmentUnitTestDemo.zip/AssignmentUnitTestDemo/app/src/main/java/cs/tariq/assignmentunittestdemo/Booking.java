package cs.tariq.assignmentunittestdemo;

import java.util.ArrayList;
import java.util.List;

public class Booking {
    ArrayList timeslots = new ArrayList<Timeslot>();
    String []days = {"Mon", "Tues", "Wed", "Thur", "Fri"};

    public Booking() {
        for(int d=0;d<days.length;d++){
            for(int t=9;t<17;t++){
                timeslots.add( new Timeslot( days[d], t));
            }
        }
    }
    public boolean bookTimeSlot(Customer customer, String day, int hour){
        if(hour<9 || hour >17)
            return false;
        //Write code to add booking

        return true;
    }
}
