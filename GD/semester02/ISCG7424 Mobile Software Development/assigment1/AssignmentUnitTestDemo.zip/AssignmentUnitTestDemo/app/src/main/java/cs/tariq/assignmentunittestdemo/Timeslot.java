package cs.tariq.assignmentunittestdemo;

import java.util.ArrayList;
import java.util.List;

public class Timeslot {
    private List customerList = new ArrayList<Customer>();
    private String day;
    private  int hour;

    public Timeslot(String day, int hour) {
        this.day = day;
        this.hour = hour;
    }

    public List getCustomerList() {
        return customerList;
    }

    public void setCustomerList(List customerList) {
        this.customerList = customerList;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public int getHour() {
        return hour;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }
}
