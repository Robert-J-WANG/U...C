package nz.ac.op.cs.dbdemo2.db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface NotesDao {
    @Insert
    void insertNotes(Notes n);

    @Update
    void updateNotes(Notes n);

    @Query("SELECT * FROM Notes;")
    List<Notes> getAll();

    @Query("SELECT * FROM Notes Where id=:nid")
    Notes getNote(long nid);

    @Query("DELETE FROM Notes;")
    void deleteAll();
}
