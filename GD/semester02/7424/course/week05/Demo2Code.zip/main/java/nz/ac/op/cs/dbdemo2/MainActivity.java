package nz.ac.op.cs.dbdemo2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import nz.ac.op.cs.dbdemo2.db.Notes;
import nz.ac.op.cs.dbdemo2.db.NotesDB;
import nz.ac.op.cs.dbdemo2.db.NotesDao;

public class MainActivity extends AppCompatActivity {
    NotesDao notesDao;
    EditText txt;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        notesDao = NotesDB.getInstance(this).notesDao();
        txt  = findViewById(R.id.txt);
        tv = findViewById(R.id.tv);
    }

    public void addNew(View view) {
        //Notes s = new Notes("This is notes ");
        //notesDao.insertNotes(s);
        String text = txt.getText().toString();
        if(text.length()<2)
            Toast.makeText(this,
                    "Error: You need to enter note ",Toast.LENGTH_SHORT).show();
        else {
            Notes note = new Notes(text);
            notesDao.insertNotes(note);
            Toast.makeText(this,
                    "Success: Note added to database ",Toast.LENGTH_SHORT).show();
        }
    }

    public void displayAll(View view) {
        List<Notes> notes = notesDao.getAll();
        String listStr="";
        for(Notes n: notes)
            listStr += n.toString();

        tv.setText(listStr);
        tv.setMovementMethod(new ScrollingMovementMethod());
        //Notes n = notesDao.getNote(1);
        //tv.setText(n.toString());

        //Toast.makeText(this, listStr,Toast.LENGTH_LONG).show();
    }

    public void deleteAll(View view) {
        notesDao.deleteAll();
        tv.setText("All Notes Deleted");

    }

    public void getNote(View view) {
        try {
            long id = Long.parseLong(txt.getText().toString());
            Notes n = this.notesDao.getNote(id);
            tv.setText(n.toString());
        }catch(Exception e){
            Toast.makeText(this,
                    "Error note not exist",Toast.LENGTH_SHORT).show();

        }
    }
}
