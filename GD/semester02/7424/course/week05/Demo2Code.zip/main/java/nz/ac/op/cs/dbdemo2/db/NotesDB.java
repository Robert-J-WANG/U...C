package nz.ac.op.cs.dbdemo2.db;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;


@Database(entities = {Notes.class}, version = 1,
        exportSchema = false)
public abstract class NotesDB  extends RoomDatabase {

    private static NotesDB notesDatabase = null;

    public abstract NotesDao notesDao();

    public static NotesDB getInstance(Context context) {
        if (notesDatabase == null) {
            notesDatabase = Room.databaseBuilder(
                    context.getApplicationContext(),
                    NotesDB.class,
                    "notes_database"
            ).allowMainThreadQueries().build();
        }
        return notesDatabase;
    }
}
