package nz.ac.op.cs.dbdemo2.db;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Notes {
    @PrimaryKey(autoGenerate = true)
    long id;
    String note;

    public Notes(String note) {
        this.note = note;
    }

    public long getId() {
        return id;
    }
    public String getNote() {
        return note;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setNote(String note) {
        this.note = note;
    }

    @Override
    public String toString() {
        return "ID :" + id +"\n"+
                "Note:" + note + "\n\n";

    }
}
